package com.placement.student.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.placement.student.entity.Student;

public interface StudentRepo extends JpaRepository<Student, Long> {
	

}
