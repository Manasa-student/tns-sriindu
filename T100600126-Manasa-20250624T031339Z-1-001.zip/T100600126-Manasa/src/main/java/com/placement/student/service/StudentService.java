package com.placement.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.student.entity.Student;
import com.placement.student.repository.StudentRepo;

//curd operational methods


@Service
public class StudentService {
	
	//autowired is a annoation using for linking the repo
	@Autowired
	private StudentRepo srepo;
	
//operations
	
//1.insert the data
	public Student addStudent(Student st) {
		return srepo.save(st);
		
	}
	
//2.get the data-->reading the data
	public List<Student>getst(Student st){
		return srepo.findAll();
	}
//3.update data
	public Student updateStudent(Student st) {
		long id=st.getId();
		Student st1=srepo.findById(id).get();
		st1.setName(st.getName());
		st1.setCollege(st.getCollege());
		st1.setRoll(st.getRoll());
		st1.setQualification(st.getQualification());
		st1.setCourse(st.getCourse());
		st1.setYear(st.getYear());
		st1.setCertificate(st.getCertificate());
		st1.setHallticketNo(st.getHallticketNo());
		return srepo.save(st);
		
	}
//4.delete data
	public void deletestudent(long id) {
		srepo.deleteById(id);
	}
	
	
	

}
